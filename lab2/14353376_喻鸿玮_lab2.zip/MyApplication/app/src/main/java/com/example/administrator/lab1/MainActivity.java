package com.example.administrator.lab1;

import android.content.Context;
import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private ImageView mImage;
    private Button mLogin, m_Sign_up;
    private TextView camera , photograph;
    private RadioButton mRadio1, mRadio2;
    private TextInputLayout username, password;
    private EditText mStudentID, mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final boolean[] s = {true};
        mImage = (ImageView)findViewById(R.id.Image);
        mLogin = (Button)findViewById(R.id.Login);
        m_Sign_up = (Button)findViewById(R.id.sign_up);
        mRadio1 =(RadioButton) findViewById(R.id.id1);
        mRadio2 = (RadioButton)findViewById(R.id.id2);
        mStudentID = (EditText)findViewById(R.id.StudentID);
        mPassword = (EditText)findViewById(R.id.Password);
        username = (TextInputLayout)findViewById(R.id.usernameWrapper);
        password = (TextInputLayout)findViewById(R.id.passwordWrapper);

        mImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater factory  = LayoutInflater.from(MainActivity.this);//动态载入界面
                View view = factory.inflate(R.layout.choice,null);//调用预设好的弹出框layout
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                camera = (TextView) view.findViewById(R.id.exitBtn0);//获取choice文件中的id为exitBtn0的TextView
                photograph = (TextView) view.findViewById(R.id.exitBtn1);//获取choice文件中的id为exitBtn1的TextView
                builder.setTitle("上传照片");// 为弹出框加标题
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override   //为弹出框加取消按钮
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this,"您选择了[取消]",Toast.LENGTH_SHORT).show();
                        //按了取消按钮之后弹出"您选择了[取消]"提示消息。
                    }
                });
                builder.setView(view); //绘制自己设置好的界面
                final AlertDialog dialog = builder.create();// 创建对话框
                dialog.show();//需要先显示弹出框，才能查找控件
                camera.setOnClickListener(new View.OnClickListener() {
                    @Override   //为“拍照”设置触控监听，弹出"您选择了[拍照]"
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this,"您选择了[拍照]",Toast.LENGTH_SHORT).show();
                    }
                });
                photograph.setOnClickListener(new View.OnClickListener() {
                    @Override   //为“从相册选择”设置触控监听，弹出"您选择了[从相册选择]"
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this,"您选择了[从相册选择]",Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        mStudentID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username.getEditText().getText().toString();
                if(TextUtils.isEmpty(username1)){
                    username.setError("学号不能为空");
                }else {
                    username.setErrorEnabled(false);
                }
            }
        });

        mPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password1 = password.getEditText().getText().toString();
                if (TextUtils.isEmpty(password1)){
                    password.setError("密码不能为空");
                }
                else {
                    password.setErrorEnabled(false);
                }
            }
        });

        mRadio1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(mRadio1, "您选择了学生",Snackbar.LENGTH_INDEFINITE)
                        .setAction("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                            }
                        })
                        .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                        .setDuration(5000)
                        .show();
                s[0] = true;
            }
        });
        mRadio2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(mRadio2, "您选择了教职工",Snackbar.LENGTH_INDEFINITE)
                        .setAction("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                            }
                        })
                        .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                        .setDuration(5000)
                        .show();
                s[0] = false;
            }
        });

        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username.getEditText().getText().toString();
                String password1 = password.getEditText().getText().toString();
                if(username1.equals("1234567") && password1.equals("6666")){
                    Snackbar.make(mLogin, "登陆成功",Snackbar.LENGTH_INDEFINITE)
                            .setAction("确定", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            })
                            .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                            .setDuration(5000)
                            .show();
                }else{
                    Snackbar.make(mLogin, "学号或密码错误",Snackbar.LENGTH_INDEFINITE)
                            .setAction("确定", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            })
                            .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                            .setDuration(5000)
                            .show();
                }
            }
        });

        m_Sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(s[0]){
                    Snackbar.make(m_Sign_up, "学生注册功能尚未启用",Snackbar.LENGTH_INDEFINITE)
                            .setAction("确定", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            })
                            .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                            .setDuration(5000)
                            .show();
                }else {
                    Snackbar.make(m_Sign_up, "教职工注册功能尚未启用",Snackbar.LENGTH_INDEFINITE)
                            .setAction("确定", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            })
                            .setActionTextColor(getResources().getColor(R.color.colorPrimary))
                            .setDuration(5000)
                            .show();
                }
            }
        });
    }
}
